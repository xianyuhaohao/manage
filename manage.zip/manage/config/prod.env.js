'use strict'
module.exports = {
  NODE_ENV: '"production"',
  NODE_API:{
    manage:'"/manage"',
  }
}